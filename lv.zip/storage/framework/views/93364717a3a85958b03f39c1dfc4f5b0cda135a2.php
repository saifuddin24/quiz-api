<?php $__env->startSection('content'); ?>
    <h2>Admin Page</h2>
    <App></App>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\lp\resources\views/admin.blade.php ENDPATH**/ ?>
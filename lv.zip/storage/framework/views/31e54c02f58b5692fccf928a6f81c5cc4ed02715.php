<div>
    ok...
    <?php echo $__env->yieldContent('view-item'); ?>
</div>
<?php /**PATH E:\xampp\htdocs\quiz-circle\app\resources\views/doc/view-item.blade.php ENDPATH**/ ?>
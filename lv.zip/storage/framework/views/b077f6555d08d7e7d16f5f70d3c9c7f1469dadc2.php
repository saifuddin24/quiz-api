<?php use \App\Doc\DocumentRequest;  ?>
<div style="margin-left: 5px; min-height: <?php echo e($item['is_group_title'] ? "5px":"300px"); ?>">
    <h2>
        <a name="<?php echo e(DocumentRequest::indexKey( $item['title'])); ?>"
           href="<?php echo e(url( "#" . DocumentRequest::indexKey( $item['title']) )); ?>"><?php echo e($item['title']); ?></a>
    </h2>

    <?php if( !$item['is_group_title'] ): ?>
        <?php $item = DocumentRequest::findItemById( $item['id'] ) ?>

        <p><?php echo e($item->method); ?> <?php echo e($item->url); ?></p>
    <?php endif; ?>

</div>

<?php /**PATH E:\xampp\htdocs\quiz-circle\app\resources\views/doc/request-item.blade.php ENDPATH**/ ?>
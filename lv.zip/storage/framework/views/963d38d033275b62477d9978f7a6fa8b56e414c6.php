<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Documentation</title>

    <!-- Scripts -->
    <script src="<?php echo e(url('public/js/app.js')); ?>" defer></script>
    <script src="<?php echo e(url('public/js/bootstrap.min.js')); ?>" defer></script>
    <script src="<?php echo e(url('public/js/bootstrap.bundle.min.js')); ?>" defer></script>

    <!-- Styles -->
    <link href="<?php echo e(url('public/css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('public/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('public/css/bootstrap-grid.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('public/css/bootstrap-reboot.min.css')); ?>" rel="stylesheet">

</head>
<body>
<div id="app">


    <main class="h-screen flex">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</div>
</body>
</html>
<?php /**PATH E:\xampp\htdocs\quiz-circle\app\resources\views/doc/main.blade.php ENDPATH**/ ?>
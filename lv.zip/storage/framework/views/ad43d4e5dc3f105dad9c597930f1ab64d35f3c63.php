<?php use \App\Doc\DocumentRequest;  ?>


<?php $__env->startSection('content'); ?>

    <div class="w-25 h-full fixed overflow-y-auto">
        <ul class="p-6">
            <?php if( isset($list_index) &&  is_array($list_index)): ?>
                <?php $__currentLoopData = $list_index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li> <a href="<?php echo e(url( "#" . DocumentRequest::indexKey( $list_item['title']) )); ?>"><?php echo e($list_item['title']); ?></a>

                        <?php if( isset( $list_item[ 'parents'] ) && is_array( $list_item[ 'parents'] )): ?>
                            <?php $__currentLoopData = $list_item[ 'parents']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <ul style="margin-left: 30px">
                                    <li>
                                        <a href="<?php echo e(url( "#" . DocumentRequest::indexKey( $parent_list['title']) )); ?>"><?php echo e($parent_list['title']); ?></a>
                                    </li>
                                </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
    </div>


    <div class="w-75 ml-auto">
        <div class="p-6">
            <?php if( isset($list_index) &&  is_array($list_index)): ?>
                <?php $__currentLoopData = $list_index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex-col">
                        <?php echo $__env->make("doc/request-item", ['item'=> $list_item] , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php if( isset( $list_item[ 'parents'] ) && is_array( $list_item[ 'parents'] )): ?>
                            <?php $__currentLoopData = $list_item[ 'parents']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make("doc/request-item", ['item'=> $parent_list] , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <div class="footer" style="min-height: 500px">

        </div>
    </div>














<?php $__env->stopSection(); ?>

<?php echo $__env->make('doc.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\quiz-circle\app\resources\views/doc/view-all.blade.php ENDPATH**/ ?>
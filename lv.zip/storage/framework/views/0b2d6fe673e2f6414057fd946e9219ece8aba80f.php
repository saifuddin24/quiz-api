<?php $__env->startSection('content'); ?>

<div class="mx-auto h-full flex justify-center items-center bg-gray-300 flex-col">
    <div class="w-96 bg-blue-900 rounded-lg shadow-xl p-6">
        <h1 class="text-2xl text-white">Welcome back</h1>
        <p class="text-blue-200">Enter your credentials bellow</p>

        <form method="POST" action="<?php echo e(route('login')); ?>" class="mt-6">
            <?php echo csrf_field(); ?>

            <div class=" bg-blue-700 p-1">
                <label for="email" class="uppercase text-blue-300 text-xs font-bold ">E-Mail</label>

                <div class="">
                    <input id="email" type="email" class="p-1 w-full bg-blue-800 outline-none focus:bg-blue-900 text-white" name="email" value="<?php echo e(old('email')); ?>"

                           autocomplete="email" autofocus placeholder="your@email.com">

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="w-full text-right block text-sm text-red-400" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class=" bg-blue-700 mt-5 p-1">
                <label for="password" class="uppercase text-blue-300 text-xs font-bold " >Password</label>

                <div class="">
                    <input id="password" type="password" class="p-1 w-full bg-blue-800 outline-none focus:bg-blue-900 text-white" name="password"
                           placeholder="password"
                           autocomplete="current-password">

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="w-full text-right block text-sm text-red-400" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="mt-5">

                <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                <label class="text-white cursor-pointer" for="remember">
                    <?php echo e(__('Remember Me')); ?>

                </label>

            </div>

            <div class="mt-1">
                <button type="submit" class="w-full bg-gray-300 p-1 hover:bg-gray-400 uppercase font-bold text-blue-700 rounded shadow-2xl">
                    <?php echo e(__('Login')); ?>

                </button>

                <div class="mt-4 flex justify-between w-full">

                    <?php if(Route::has('password.request')): ?>
                        <a class="text-gray-500 hover:text-gray-300 " href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(__('Forgot Your Password?')); ?>

                        </a>
                    <?php endif; ?>

                    
                        <a class="text-gray-500 hover:text-gray-300" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                    
                </div>
            </div>

        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\familymart.xyz\resources\views/auth/login.blade.php ENDPATH**/ ?>
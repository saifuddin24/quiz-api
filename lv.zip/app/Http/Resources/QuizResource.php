<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class QuizResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $data = [
            'id' => $this->id,
            'title' => $this->title,
            'description' => $this->description,
            'full_marks' => $this->full_marks,
            'negative_marks_each' => $this->negative_marks_each,
            'negative_mark_type' => $this->negative_mark_type,
            'user_id' => $this->user_id,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];


        if( $request->user() && $request->user()->isAdmin() ) {
            $data['publish'] = $this->publish;
            $data['deleted_at'] = $this->deleted_at;
        }

        return  $data;
    }
}

<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class QuestionResource extends JsonResource
{
    public static $isAssignedList = false;
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request) {

        $data = [];

        if( self::$isAssignedList ) {
            $data['assigned_id'] = $this->id;
            $data['quiz_id'] = $this->quiz_id;
            $data['question_id'] = $this->question_id;
            $data['position'] = $this->position;
            $data['question_data'] = $this->question_data == null ? null : json_decode( $this->question_data );
        }else {
            $data['id'] = $this->id;
            $data['user_id'] = $this->user_id;
            $data['created_at'] = $this->created_at;
            $data['updated_at'] = $this->updated_at;
        }

        $data[ 'category_names' ] = $this->category( )->pluck( 'name' );
        $data[ 'category_ids' ] = $this->category( )->pluck( 'categories.id' );

        $data[ 'title'] = $this->title;
        $data[ 'answer'] = $this->answer;
        $data[ 'description'] = $this->description;

        if( $request->user() && $request->user()->isAdmin() ) {
            $data[ 'hidden' ] = $this->hidden;
            $data[ 'deleted_at' ] = $this->deleted_at;
            $data[ 'categories' ] = $this->category_list( );
            $data[ 'meta_list' ] = $this->meta( )->where('group', 'opts')->get(['id','meta_name','meta_value']);
        }

        return $data;
    }
}

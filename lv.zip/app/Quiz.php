<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Quiz extends Model
{
    use SoftDeletes;

    public static $relatedQuestColumns = [
        "quiz_id", "question_id", "question_data", "position", "title", "questions.answer",
        "description", "user_id", "deleted_at", "quest_assign.id as assigned_id"
    ];

    private $questionIds = [], $quiz_id, $questionsData = [], $questionAnswers = [];

    public function questionRelation( ){
        return Question::join('quest_assign', 'questions.id', '=', 'quest_assign.question_id' )
            ->where( 'quiz_id', $this->id )->select( self::$relatedQuestColumns);
    }

    public function hasQuestions(){
        return $this->questionRelation()->exists();
    }



    public function assignQuestions( $quiz_id = null, $questions = null, $questionsData = []){
        if( is_array($quiz_id) ) {
            $questionsData = $questions;
            $questions = $quiz_id;
            $quiz_id = $this->id;
        }

        $this->quiz_id = $quiz_id;
        $this->questionIds =  is_array( $questions ) ? $questions: [ $questions ];
        $this->questionsData = $questionsData;
        return $this;
    }


    public function setQuestionsData( $questionsData ){
        $this->questionsData = $questionsData;
        return $this;
    }

    public function setQuestionAnswers( $questionsAnswers ){
        $this->questionAnswers = $questionsAnswers;
        return $this;
    }

    public function saveAssigned( )
    {
        $result = [ 'deleted' => 0, 'updated' => 0, 'inserted' => 0, 'total' => 0, 'inserted_data' => [] ];

        $result[ 'deleted' ] =  QuestAssign::where( [ "quiz_id" => $this->quiz_id ] )
            ->whereNotIn( 'question_id', $this->questionIds )
            ->delete();

        $position = 0;
        foreach ( $this->questionIds as $question_id ) {

            if( Question::find( $question_id ) ) {

                $relation = QuestAssign::where( [ 'question_id' => $question_id, 'quiz_id' => $this->quiz_id ] );

                $quid_in = 'qid_' . $question_id;

                $assignQuestionData =  isset( $this->questionsData[ $quid_in ] )
                    ? $this->questionsData[ $quid_in ] : null;


                $exists = $relation->exists( );
                $saved = false;

                $assignment = $exists ? QuestAssign::find( $relation->first()->id ):new QuestAssign( );

                $assignment->question_id = $question_id;
                $assignment->quiz_id = $this->quiz_id;

                if( isset( $this->questionAnswers[ $quid_in ] ) ) {
                    $assignment->answer = $this->questionAnswers[ $quid_in ];
                }else  if( $question = Question::find( $question_id )) {
                    $assignment->answer = $question->answer;
                }

                //dd( $assignQuestionData);

//                $assignment->question_data = empty( $assignQuestionData ) ?  json_encode( ['dddd' => 78 ]):'{"p":458}';
                $assignment->question_data =  !empty( $assignQuestionData ) ? json_encode($assignQuestionData) : $assignment->question_data;
                $assignment->position =  ++$position;

                $saved = $assignment->save( );

                if( !$exists ){
                    $result['inserted_data'][] = $assignment;
                }

                if( $saved ) {
                    if( $assignment->wasRecentlyCreated ) {
                        $result[ 'inserted' ]++;
                    }else {
                        $result[ 'updated' ]++;
                    }
                }

            }

        }


        $result['total'] =  QuestAssign::where( [ 'quiz_id' => $this->quiz_id ] )->count();

        return $result;
    }

    public  function questionCount( ){

        return (int) $this->questionRelation( )
            ->where( 'question_data', '!=', '[]')
            ->orWhere( 'question_data', ' IS NOT ', 'NULL')->count();
    }

    public  function markEach( ){

        $total_questions = (int) $this->questionRelation( )
            ->where( 'question_data', '!=', '[]')
            ->orWhere( 'question_data', ' IS NOT ', 'NULL')->count();

        $full_marks = (int) $this->full_marks;

        return $full_marks / $total_questions;
    }

}
